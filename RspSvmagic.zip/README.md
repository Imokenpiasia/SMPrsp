# Magic Low-Res Resource Pack

This RP is meant for use with the Magic Bukkit plugin:

https://github.com/elBukkit/MagicPlugin/wiki

## RP Credits

- 3D Artist: Dr00bles
- 2D Artists:
  - Dr00bles
  - eleazzaar
- Sound Effects:
  - Dr00bles
  - S-Toad (Flute samples for Ocarina)
